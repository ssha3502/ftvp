# Import necessary libraries
import random
import shutil
import xbmcaddon,os,xbmc
global global_var,site_id,sub_color#global
global_var=[]
from resources.modules import log
import json,re
import urllib
from resources.modules.extract_sub import extract
import xbmcvfs
#########################################

que=urllib.parse.quote_plus
Addon=xbmcaddon.Addon()
MyScriptID=Addon.getAddonInfo('id')
xbmc_tranlate_path=xbmcvfs.translatePath
__profile__ = xbmc_tranlate_path(Addon.getAddonInfo('profile'))
MyTmp = xbmc_tranlate_path(os.path.join(__profile__, 'temp_telegram'))

########### Constants ###################
site_id='[Tele]'
sub_color='deepskyblue'
AllSubsNew_GROUP_ID = -1001918401150
AllSubsNew_CHANNEL_ID = -1002086580511
AllSubsNew_Kodi_Subs_THREAD_ID = 7051673600
AllSubsNew_INVITE_LINK = 'https://t.me/+Ce2c6bYTX2lhMWJk'
#########################################
#########################################

def extract_season_episode_numbers(telegram_message_file_name):

    optional_separators = r'[\s._\-x+,&:]{0,2}' # 0-2 occurrences
    optional_middle_separators = r'[\s._\-x+,&:]{0,4}' # 0-4 occurrences

    regex_pattern = re.compile(r'S[e]?(?:ason)?' + optional_separators + '(?P<season_number>\d{1,2})' + optional_middle_separators + 'E[p]?(?:isode)?' + optional_separators + '(?P<episode_number>\d{1,3})', re.IGNORECASE)
    # episode=re.findall(r"(?:e|x|episode|\n)(\d{2})", telegram_message_file_name, re.I)
    match = regex_pattern.search(telegram_message_file_name)
    if match:
        extracted_season_number = match.group('season_number').zfill(2) # Fill leading zero if needed
        extracted_episode_number = match.group('episode_number').zfill(2) # Fill leading zero if needed
        return extracted_season_number, extracted_episode_number

    return None, None
       
def get_subs(video_data):
    # For settings changes to take effect.
    log.warning(video_data)
    Addon=xbmcaddon.Addon()
    global global_var
    media_type = video_data["media_type"]
    title = video_data.get('OriginalTitle', '').lower().replace(' ', '.')
    
    season = video_data.get('season', '')
    episode = video_data.get('episode', '')
    imdb_id = video_data.get('imdb', '')
    year = video_data.get('year', '')
    if video_data['media_type']=='tv':
        if len(episode)==1:
          episode_n="0"+episode
        else:
           episode_n=episode
        if len(season)==1:
          season_n="0"+season
        else:
          season_n=season
        title=title+'.S%sE%s'%(season_n,episode_n)
    search_query_list = [title, imdb_id] # Example: ["No Way Up", "tt16253418"]
    log.warning(f"TeleSubs | video_data={str(video_data)}")
    log.warning(f"TeleSubs | query={str(search_query_list)}")
    
    num=random.randint(1,1001)
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    all_telegram_search_results=[]

    for search_query in search_query_list:
        import requests
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchChatMessages','chat_id':(AllSubsNew_CHANNEL_ID), 'query': search_query,'from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
             }

        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if 'status' in event:
            return
        try:
            if "Chat not found" in event['message']:
                    joinChat()
                    xbmc.sleep(2000)
                    data={'type':'td_send',
                         'info':json.dumps({'@type': 'searchChatMessages','chat_id':(AllSubsNew_CHANNEL_ID), 'query': search_query,'from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
                         }

                    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        except: pass
        all_telegram_search_results.extend(event['messages'])

    telegram_found_subtitles_files=[]
    subtitle_list=[]
    
    for telegram_message in all_telegram_search_results:
    
        telegram_message_file_name = telegram_message['content']['document']['file_name'].replace('_', '.').replace(' ', '.')
        
        # Skip over already added subtitles
        # Skip over ZIP files from @ScrewZiraBot (always contains more than 1 subtitles)
        if (telegram_message_file_name in telegram_found_subtitles_files) or (telegram_message_file_name.startswith('@ScrewZiraBot') and telegram_message_file_name.endswith('.zip')):
            continue
        if telegram_message_file_name.endswith('.zip'):
            continue

        telegram_found_subtitles_files.append(telegram_message_file_name)
        
        #####################################################################################################################
        # TV Shows Season/Episode Number Matching
        if media_type == 'tv':
            extracted_season_number, extracted_episode_number = extract_season_episode_numbers(telegram_message_file_name)
            # Skip subtitle on "None" values - no season/episode extraction found
            if not extracted_season_number and not extracted_episode_number:
                continue
            
            # Check if season and extracted_season_number are equal (boolean)
            season_matches = int(season) == int(extracted_season_number)
            # Check if episode and extracted_episode_number are equal (boolean)
            episode_matches = int(episode) == int(extracted_episode_number)
            
            if not season_matches or not episode_matches:
                continue
        else:
            regex=r'(?ix)(?:E|e|episode)(\d{1})'
            m=re.compile(regex).findall(telegram_message_file_name)
            if len(m)>0:
                continue    

            regex='.*([1-3][0-9]{3})'
            year_pre=re.compile(regex).findall(telegram_message_file_name)
            
            year_z=0
            
            if len(year_pre)>0:
                year_z=year_pre[0].replace('2160','').replace('1080','').replace('720','').replace('480','')
                if year_z not in year:
                 continue

                ##############################################################################################
        telegram_message_caption = telegram_message['content']['caption']['text'].replace('\n',' ')
        
        file_id=telegram_message['content']['document']['document']['id']
        
        telegram_subtitle_display_name = telegram_message_file_name
        strings_to_replace = [
            'TranslationsMoviesHEB.t.me HEB',
            'TranslationsMoviesHEB HEB',
            'TranslationsMoviesHEB.t.me',
            'TranslationsMoviesHEB',
            '@ScrewZiraBot_',
            '@ScrewZiraBot-',
            '@ScrewZiraBot',
            '.srt',
            '.ass',
            '.sub',
            '.idx',
            '.sup',
        ]
        for string in strings_to_replace:
            telegram_subtitle_display_name = telegram_subtitle_display_name.replace(string, '') # Replace to none
        
        language = "Hebrew"
        if 'Imdb:' in telegram_message_caption and 'תרגום מכונה' in telegram_message_caption:
            telegram_subtitle_display_name = f'[COLOR khaki](תרגום מכונה)[/COLOR] {telegram_subtitle_display_name}'
            language = "HebrewMachineTranslated"
            
        download_data = {}
        download_data['filename'] = telegram_message_file_name
        download_data['id'] = file_id
        download_data['format'] = "srt"
        url = "plugin://%s/?action=download&filename=%s&id=%s&download_data=%s&source=telesubs&language=%s" % (
                MyScriptID, que(telegram_message_file_name), file_id, que(json.dumps(download_data)), language)

        json_data={'url':url,
                         'label':language,
                         'label2':site_id+' '+telegram_subtitle_display_name,
                         'iconImage':"",
                         'thumbnailImage':"he",
                         'hearing_imp':'false',
                         'site_id':site_id,
                         'sub_color':sub_color,
                         'filename':telegram_message_file_name,
                         'sync': 'false'}

      
        subtitle_list.append(json_data)
                
    global_var=subtitle_list
    
def download(download_data,MySubFolder):
    import requests
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    try:
        shutil.rmtree(MyTmp)
    except: pass
    xbmcvfs.mkdirs(MyTmp)
    file_id=download_data['id']
    filename=download_data['filename']
    
    MyTmpSubFile = os.path.join(MyTmp, str(filename))
    log.warning(f'TeleSubs | Desired sub filename: {filename} | file_id: {file_id} | MyTmpSubFile: {MyTmpSubFile}')
    
    
    data={
            'type': 'download_photo',
            'info': file_id
         }
    sub_file=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    
    # Copy the downloaded sub_file to MyTmpSubFile path (temp_telesubs)
    try:
        shutil.copy(sub_file, MyTmpSubFile)
        sub_file = MyTmpSubFile
    except:
        pass

    return sub_file
    


def upload_subtitle_to_telegram(sub_file_to_upload,filename_to_upload,caption,source):
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    import requests
    from resources.modules.general import get_video_data
    imdb_id = get_video_data()['imdb']

    upload_message_caption = f"Imdb: {imdb_id}{caption}\nSource: {source}"
    # search srt
    try:
        num=random.randint(1,1001)
        data={'type':'td_send',
             'info':json.dumps({'@type': 'searchChatMessages','chat_id':(AllSubsNew_CHANNEL_ID), 'query': filename_to_upload,'from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
             }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    except Exception as e:
        pass
        log.warning(f"TeleSubs | upload_subtitle_to_telegram | Exception: {str(e)}")

    if 'status' in event:
        return
        
    for items in event['messages']:
        telegram_search_result_file_name=items['content']['document']['file_name']
        
        extensions_to_remove = ['.srt', '.sub', '.sup', '.idx', '.ass']
        for extension in extensions_to_remove:
            if filename_to_upload.lower().replace(extension, '') == telegram_search_result_file_name.lower().replace(extension, ''):
                # Exit function if subtitle already in Telegram group.
                log.warning(f"TeleSubs | upload_subtitle_to_telegram | Subtitle already exists in telegram | filename_to_upload={filename_to_upload}")
                return
    try:
        num=random.randint(1,1001)
        data={'type':'td_send',
                     'info':json.dumps({'@type': 'sendMessage','chat_id': (AllSubsNew_CHANNEL_ID), 'input_message_content': {'@type':'inputMessageDocument','document': {'@type':'inputFileLocal','path': sub_file_to_upload},'caption': {'@type':'FormattedText','text': upload_message_caption}},'@extra': num })
                     }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        if 'Need administrator rights in the channel chat' in event['message']:
            # Upload From Bot
            upload_message_caption = f"Imdb: {imdb_id}{caption}\nSource: {source}\nUpload From Bot"
            files = {
            'chat_id': (None, AllSubsNew_CHANNEL_ID),
            'document': (open(sub_file_to_upload, 'rb')),
            'caption':(None,upload_message_caption)
            }
        
            document='https://api.telegram.org/bot1780462945:AAE5y-Aqh17-VBiKphPJca9Ip-ryFNYM5rY/sendDocument'
            response = requests.post(document, files=files)
        log.warning(f"TeleSubs | upload_subtitle_to_telegram | Subtitle uploaded successfully | filename_to_upload={filename_to_upload}")
    except Exception as e:
        pass
        log.warning(f"TeleSubs | upload_subtitle_to_telegram | Exception: {str(e)}")

def joinChat():
    import requests
    try:
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        num=random.randint(1,1001)
        data={'type':'td_send',
         'info':json.dumps({'@type': 'joinChatByInviteLink', 'invite_link': AllSubsNew_INVITE_LINK, '@extra': num})
         }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    except Exception as e:
        pass
        log.warning(f"TeleSubs | joinChat | Exception: {str(e)}")