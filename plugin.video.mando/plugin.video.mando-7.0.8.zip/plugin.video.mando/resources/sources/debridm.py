# -*- coding: utf-8 -*-
import re
import time

global global_var,stop_all#global
global_var=[]
stop_all=0
from  resources.modules.client import get_html
 
from resources.modules.general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,all_colors,base_header
from  resources.modules import cache
try:
    from resources.modules.general import Addon,get_imdb
except:
  import Addon
type=['movie','tv','torrent']

import urllib,logging,base64,json

from resources.modules import log

try:
    que=urllib.quote_plus
except:
    que=urllib.parse.quote_plus
color=all_colors[112]

def get_secret():
    import ctypes,math
    def from_char_code(e,s):
        return ord(e[s])
    def random_number():
        import random

        ran = random.randrange(10**80)
        myhex = "%064x" % ran

        #limit string to 64 characters
        myhex = myhex[:8]

        return myhex
    def get_unix_time():
        import time

        return int(time.time()) 
    def calc_value_alg(t,n,const):
        temp=t^n

        t=ctypes.c_long((temp*const)).value
        t4=ctypes.c_long(t<<5).value

        x32 = t & 0xffffffff   # convert to 32-bit unsigned value

        t5=ctypes.c_long(x32 >> 27  ).value

        t6=t4 | t5

        return t6
    def slice(e,t):
        a =math.floor(len(e) / 2)
        print (a)
        s = e[0: a]
        print (s)
        n = e[a:]
        print (n)
        i = t[0: a]
        print (i)
        o = t[a:]
        print (o)
        l = ""
        for e in range(0,a):
            l += s[e] + i[e]
        
        temp=l + (o[::-1] + n[::-1])
        print(temp)
        return temp
                    
    def generateHash(e):
        t=int(3735928559) ^ int(len(e))
        
        
        t= ctypes.c_long(t).value
        

        a = 1103547991 ^ len(e)
      
        for s in range(len(e)):
            n =from_char_code(e,s) 
            
            t=calc_value_alg(t,n,2654435761)
            
            
            
            #a=(a ^ n*1597334677) << 5 | a >> 27
            a=calc_value_alg(a,n,1597334677)
            
            
        

        t_o=t
        t =ctypes.c_long( t + ctypes.c_long(a* 1566083941).value | 0).value
        

        a =ctypes.c_long(  a + ctypes.c_long(t* 2024237689).value | 0).value

        return ((ctypes.c_long(t ^ a).value& 0xffffffff) >> 0)
                
    e=random_number()
    t=get_unix_time()


    a=str(e)+'-'+str(t)

  
    s=generateHash(a)
    s=hex(s).replace('0x','')

    n = generateHash("691Rbf3#aI@JL84xDD!2" + e)
    n=hex(n).replace('0x','')
 
    i=slice(s,n)
    dmmProblemKey=a
    solution=i
    return dmmProblemKey,solution
dmmProblemKey,solution=get_secret()
def get_links(tv_movie,original_title,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    imdb_id=cache.get(get_imdb, 999,tv_movie,id,table='pages')
        
    
    added_season=''
    if tv_movie=='tv':
    
        added_season='&seasonNum='+str(season)
    dmmProblemKey,solution=get_secret()
    o_url=f'https://debridmediamanager.com/api/torrents/{tv_movie}?imdbId={imdb_id}{added_season}&dmmProblemKey={dmmProblemKey}&solution={solution}&onlyTrusted=false&page=%s'
    
    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'en-US,en;q=0.9',
        
        'priority': 'u=1, i',
        
        'sec-ch-ua': '"Microsoft Edge";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0',
    }
    for page in range(4):
        url=o_url%str(page)
     
        x=get_html(url,headers=headers).json()
        
        for results in x['results']:

                if stop_all==1:
                    break
                nam=results['title']
                size=(float(results['fileSize'])/(1024))
     
                links=results['hash']
                lk='magnet:?xt=urn:btih:%s&dn=%s'%(links,que(original_title))
                if '4k' in nam:
                      res='2160'
                elif '2160' in nam:
                      res='2160'
                elif '1080' in nam:
                          res='1080'
                elif '720' in nam:
                      res='720'
                elif '480' in nam:
                      res='480'
                elif '360' in nam:
                      res='360'
                else:
                      res='HD'
                max_size=int(Addon.getSetting("size_limit"))
                
                
                if (size)<max_size:
                   
                    all_links.append((nam,lk,str(size),res))

                    global_var=all_links
    return global_var