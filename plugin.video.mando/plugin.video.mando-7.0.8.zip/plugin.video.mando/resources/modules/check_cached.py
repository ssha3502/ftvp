from  resources.modules.client import get_html
from resources.modules import log
import json
def chack_hashed(hash_list,imdbId):
    log.warning(hash_list)
    headers = {
        'accept': '*/*',
        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'cache-control': 'no-cache',
        'content-type': 'application/json',
        # 'cookie': 'cf_clearance=grPLmX3Ze9UWq3CvKGHD4R1XkQ9eVYlhnaUkedG2I.w-1733035082-1.2.1.1-lKTl0dI5l1dGaywV8aofkgH9QV7DyFljnNItjmmKF0PYbQ51a5XDG5GTs6kZnJxJAdRrSgwYNzH48QC0wrD9ZdHnUxDLSnZHvv_nwqADoyD._1dYOJFBjs32YAU5qnyW7SThGNqcoRWcoAwb9dT68aMTM83EJH0v3WoqK5xATQBZ5Iv5PmemjQfq3ODkZVn20In5wtvHdvmBOV.95fJL7oFkOpnDEELtFuZ1NEzTB3ydU0uaih4a57Lf4Y03pzUW8w4Qu9015La3qRGdRingkNMoZxXtj3bpkjmpU2D1UpsuvZN.5cj.WCGL27wvJbajyIxk5ODLVMn2PyrwXA2dWPdeNrZgnraV5KkJsyfvgIg_nZPIlK9IBGUmI_8TJrmWjbm0UPXQ_WRl1zJxYqKD4w',
        'dnt': '1',
        'origin': 'https://debridmediamanager.com',
        'pragma': 'no-cache',
        'priority': 'u=1, i',
        
        'sec-ch-ua': '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    }
    def get_secret():
        import ctypes,math
        def from_char_code(e,s):
            return ord(e[s])
        def random_number():
            import random

            ran = random.randrange(10**80)
            myhex = "%064x" % ran

            #limit string to 64 characters
            myhex = myhex[:8]

            return myhex
        def get_unix_time():
            import time

            return int(time.time()) 
        def calc_value_alg(t,n,const):
            temp=t^n

            t=ctypes.c_long((temp*const)).value
            t4=ctypes.c_long(t<<5).value

            x32 = t & 0xffffffff   # convert to 32-bit unsigned value

            t5=ctypes.c_long(x32 >> 27  ).value

            t6=t4 | t5

            return t6
        def slice(e,t):
            a =math.floor(len(e) / 2)
            print (a)
            s = e[0: a]
            print (s)
            n = e[a:]
            print (n)
            i = t[0: a]
            print (i)
            o = t[a:]
            print (o)
            l = ""
            for e in range(0,a):
                l += s[e] + i[e]
            
            temp=l + (o[::-1] + n[::-1])
            print(temp)
            return temp
                        
        def generateHash(e):
            t=int(3735928559) ^ int(len(e))
            
            
            t= ctypes.c_long(t).value
            

            a = 1103547991 ^ len(e)
          
            for s in range(len(e)):
                n =from_char_code(e,s) 
                
                t=calc_value_alg(t,n,2654435761)
                
                
                
                #a=(a ^ n*1597334677) << 5 | a >> 27
                a=calc_value_alg(a,n,1597334677)
                
                
            

            t_o=t
            t =ctypes.c_long( t + ctypes.c_long(a* 1566083941).value | 0).value
            

            a =ctypes.c_long(  a + ctypes.c_long(t* 2024237689).value | 0).value

            return ((ctypes.c_long(t ^ a).value& 0xffffffff) >> 0)
                    
        e=random_number()
        t=get_unix_time()


        a=str(e)+'-'+str(t)

      
        s=generateHash(a)
        s=hex(s).replace('0x','')

        n = generateHash("691Rbf3#aI@JL84xDD!2" + e)
        n=hex(n).replace('0x','')
     
        i=slice(s,n)
        dmmProblemKey=a
        solution=i
        return dmmProblemKey,solution
        
    dmmProblemKey,solution=get_secret()
    json_data = {
        'imdbId': imdbId,
        'hashes': hash_list,
        'dmmProblemKey': dmmProblemKey,
        'solution': solution,
    }

    r = get_html('https://debridmediamanager.com/api/availability/check', headers=headers, json=json_data,post=True).json()

    return r